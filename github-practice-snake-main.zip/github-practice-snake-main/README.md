# 他是個ReadMe，但這是作業

## 把這個專案用 `git clone`下來

## 編輯底下這句

**把這句改成能讓教學長看出是你的樣子**

## 存檔這個README.md

## 把整個repository傳到自己的GitHub然後傳給教學長

## 就完成囉~